﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMCCalc
{
    public partial class Form1 : Form
    {
        double altura, peso, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
                MessageBox.Show("Número de altura inválido!");
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
                MessageBox.Show("Número de peso inválido!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out altura) && double.TryParse(txtPeso.Text, out peso))
            {
                IMC = peso / Math.Pow(altura, 2);
                IMC = Math.Round(IMC, 1);
            }
            if (IMC < 18.5)
            {
                MessageBox.Show("Sua classificação é magreza. " + "Seu IMC é de " + IMC.ToString() );
            }
            else if (IMC <= 24.9)
                {
                    MessageBox.Show("Sua classificação é normal." + "Seu IMC é de " + IMC.ToString());
                }
                else if (IMC <= 29.9)
                    {
                        MessageBox.Show("Sua classificação é sobrepeso. " + "Seu IMC é de " + IMC.ToString() );
                    }
                else if (IMC <= 39.9)
            {
                    MessageBox.Show("Sua classificação é obesidade. " + "Seu IMC é de " + IMC.ToString() );
                }
            else if (IMC > 40)
                MessageBox.Show("Sua classificação é obesidade grave. " + "Seu IMC é de " + IMC.ToString());
            }
        }
    }

