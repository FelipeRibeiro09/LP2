﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriângulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
                MessageBox.Show("Número do Lado A é inválido!");
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
                MessageBox.Show("Número do Lado B é inválido!");
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
                MessageBox.Show("Número do Lado C é inválido!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = "";
            txtLadoB.Text = "";
            txtLadoC.Text = "";
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            {
                if (double.TryParse(txtLadoA.Text, out ladoA) && (double.TryParse(txtLadoB.Text, out ladoB) && (double.TryParse(txtLadoC.Text, out ladoC))))
                {
                    if (ladoA < (ladoB + ladoC) && (ladoA > Math.Abs(ladoB - ladoC) && (ladoB < (ladoA + ladoC) && (ladoB > Math.Abs(ladoA - ladoC) && (ladoC < (ladoA + ladoB) && (ladoC > Math.Abs(ladoA - ladoB)))))))
                    {
                        if ((ladoA == ladoB) && (ladoB == ladoC))
                            MessageBox.Show("Triângulo equilátero.");
                        else

                            if ((ladoA == ladoB) || (ladoB == ladoC) || (ladoC == ladoA))
                            {
                                MessageBox.Show("Triângulo isósceles.");
                            }
                            else
                            {
                                MessageBox.Show("Triângulo escaleno.");
                            }


                    }
                    else
                        MessageBox.Show("Não é um triângulo!");
                }
                else
                    MessageBox.Show("Dados inválidos!");
            }
        }
    }
}
