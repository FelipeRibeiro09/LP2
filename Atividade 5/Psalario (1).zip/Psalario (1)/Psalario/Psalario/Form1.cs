﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class PSalario : Form
    {
        double salbruto, numerofilhos, salfamilia, salliquido, descontoINSS, descontoIRPF;
        string casado, numfilhos;

        private void Form1_Load(object sender, EventArgs e)
        {
            cbx_filhos.Text = "0";
        }

        public PSalario()
        {
            InitializeComponent();
        }

        private void txt_funcionario_Validated(object sender, EventArgs e)
        {
            if (txt_funcionario.Text == "")
                MessageBox.Show("Digite um nome válido!");
        }

        private void mskbx_salbruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbx_salbruto.Text, out salbruto))
                MessageBox.Show("Digite um número válido!");
        }

        private void btn_verificar_Click(object sender, EventArgs e)
        {
            if (double.TryParse(mskbx_salbruto.Text, out salbruto) && double.TryParse(cbx_filhos.SelectedItem.ToString(), out numerofilhos)) 
            {
                if (salbruto <= 800.47)
                {
                    txt_aliINSS.Text = "7,65%";
                    descontoINSS = 0.0765 * salbruto;
                    txt_descINSS.Text = descontoINSS.ToString();
                }
                else if (salbruto <= 1050)
                {
                    txt_aliINSS.Text = "8,65%";
                    descontoINSS = 0.0865 * salbruto;
                    txt_descINSS.Text = descontoINSS.ToString();
                }
                else if (salbruto <= 1400.77)
                {
                    txt_aliINSS.Text = "9,00%";
                    descontoINSS = 0.0900 * salbruto;
                    txt_descINSS.Text = descontoINSS.ToString();
                }
                else if (salbruto <= 2801.56)
                {
                    txt_aliINSS.Text = "11,00%";
                    descontoINSS = 0.1100 * salbruto;
                    txt_descINSS.Text = descontoINSS.ToString();
                }
                else 
                {
                    txt_aliINSS.Text = "R$ 308,17 (teto)";
                    descontoINSS = salbruto - 308.17;
                    txt_descINSS.Text = descontoINSS.ToString();
                }
            
                if (salbruto <= 1257.00)
                {
                    txt_aliIRPF.Text = "Isento.";
                    descontoIRPF = 0;
                    txt_descIRPF.Text = descontoIRPF.ToString();
                }
                else if (salbruto <= 2512.08)
                {
                    txt_aliIRPF.Text = "15,00%";
                    descontoIRPF = 0.1500 * salbruto;
                    txt_descIRPF.Text = descontoIRPF.ToString();
                }
                else
                {
                    txt_aliIRPF.Text = "27,5%";
                    descontoIRPF = 0.2750 * salbruto;
                    txt_descIRPF.Text = descontoIRPF.ToString();
                }
            
                if (salbruto <= 435.52)
                {
                    salfamilia = numerofilhos * 22.33;
                    txt_salfamilia.Text = salfamilia.ToString();
                }
                else if (salbruto <= 654.61)
                {
                    salfamilia = numerofilhos * 15.74;
                    txt_salfamilia.Text = salfamilia.ToString();
                }
                else
                {
                    salfamilia = 0;
                    txt_salfamilia.Text = salfamilia.ToString();
                }
                salliquido = salbruto - descontoINSS - descontoIRPF + salfamilia;
                txt_salliquido.Text = salliquido.ToString();
            }
           
            if (chkbx_casado.Checked)
            {
                if (rbtn_masculino.Checked)
                {
                    casado = "casado";
                }
                else if (rbtn_feminino.Checked)
                {
                    casado = "casada";
                }
            }
            else
            {
                if (rbtn_masculino.Checked)
                {
                    casado = "solteiro";
                }
                else if (rbtn_feminino.Checked)
                {
                    casado = "solteira";
                }
            }

            if (numerofilhos == 0)
            {
                numfilhos = "não possui filhos";
            }

            if (numerofilhos == 1)
            {
                numfilhos = "possui 1 filho";
            }

            if (numerofilhos > 1)
            {
                numfilhos = "possui " + numerofilhos + " filhos";
            }

            if (rbtn_masculino.Checked)
            {
                lbl_dados.Text = "Os descontos de salário do Sr. " + txt_funcionario.Text + " que é " + casado + " e que " + numfilhos + " são: ";
            }
            else
                lbl_dados.Text = "Os descontos de salário da Sra. " + txt_funcionario.Text + " que é " + casado + " e que " + numfilhos + " são: ";
        }
    }
}
