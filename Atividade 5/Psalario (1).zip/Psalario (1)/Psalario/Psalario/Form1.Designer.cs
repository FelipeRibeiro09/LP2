﻿namespace Psalario
{
    partial class PSalario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_funcionario = new System.Windows.Forms.Label();
            this.lbl_salbruto = new System.Windows.Forms.Label();
            this.lbl_filhos = new System.Windows.Forms.Label();
            this.lbl_aliINSS = new System.Windows.Forms.Label();
            this.lbl_aliIRPF = new System.Windows.Forms.Label();
            this.lbl_salfamilia = new System.Windows.Forms.Label();
            this.lbl_saliquido = new System.Windows.Forms.Label();
            this.lbl_descINSS = new System.Windows.Forms.Label();
            this.lbl_descIRPF = new System.Windows.Forms.Label();
            this.mskbx_salbruto = new System.Windows.Forms.MaskedTextBox();
            this.txt_funcionario = new System.Windows.Forms.TextBox();
            this.cbx_filhos = new System.Windows.Forms.ComboBox();
            this.txt_aliINSS = new System.Windows.Forms.TextBox();
            this.txt_salfamilia = new System.Windows.Forms.TextBox();
            this.txt_aliIRPF = new System.Windows.Forms.TextBox();
            this.txt_descIRPF = new System.Windows.Forms.TextBox();
            this.txt_descINSS = new System.Windows.Forms.TextBox();
            this.txt_salliquido = new System.Windows.Forms.TextBox();
            this.btn_verificar = new System.Windows.Forms.Button();
            this.rbtn_masculino = new System.Windows.Forms.RadioButton();
            this.rbtn_feminino = new System.Windows.Forms.RadioButton();
            this.grpbx_sexo = new System.Windows.Forms.GroupBox();
            this.pnl_casado = new System.Windows.Forms.Panel();
            this.chkbx_casado = new System.Windows.Forms.CheckBox();
            this.lbl_dados = new System.Windows.Forms.Label();
            this.grpbx_sexo.SuspendLayout();
            this.pnl_casado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_funcionario
            // 
            this.lbl_funcionario.AutoSize = true;
            this.lbl_funcionario.Location = new System.Drawing.Point(44, 40);
            this.lbl_funcionario.Name = "lbl_funcionario";
            this.lbl_funcionario.Size = new System.Drawing.Size(93, 13);
            this.lbl_funcionario.TabIndex = 0;
            this.lbl_funcionario.Text = "Nome funcionário:";
            // 
            // lbl_salbruto
            // 
            this.lbl_salbruto.AutoSize = true;
            this.lbl_salbruto.Location = new System.Drawing.Point(44, 73);
            this.lbl_salbruto.Name = "lbl_salbruto";
            this.lbl_salbruto.Size = new System.Drawing.Size(69, 13);
            this.lbl_salbruto.TabIndex = 1;
            this.lbl_salbruto.Text = "Salário bruto:";
            // 
            // lbl_filhos
            // 
            this.lbl_filhos.AutoSize = true;
            this.lbl_filhos.Location = new System.Drawing.Point(44, 104);
            this.lbl_filhos.Name = "lbl_filhos";
            this.lbl_filhos.Size = new System.Drawing.Size(89, 13);
            this.lbl_filhos.TabIndex = 2;
            this.lbl_filhos.Text = "Número de filhos:";
            // 
            // lbl_aliINSS
            // 
            this.lbl_aliINSS.AutoSize = true;
            this.lbl_aliINSS.Location = new System.Drawing.Point(44, 286);
            this.lbl_aliINSS.Name = "lbl_aliINSS";
            this.lbl_aliINSS.Size = new System.Drawing.Size(76, 13);
            this.lbl_aliINSS.TabIndex = 3;
            this.lbl_aliINSS.Text = "Aliquota INSS:";
            // 
            // lbl_aliIRPF
            // 
            this.lbl_aliIRPF.AutoSize = true;
            this.lbl_aliIRPF.Location = new System.Drawing.Point(44, 328);
            this.lbl_aliIRPF.Name = "lbl_aliIRPF";
            this.lbl_aliIRPF.Size = new System.Drawing.Size(75, 13);
            this.lbl_aliIRPF.TabIndex = 4;
            this.lbl_aliIRPF.Text = "Aliquota IRPF:";
            // 
            // lbl_salfamilia
            // 
            this.lbl_salfamilia.AutoSize = true;
            this.lbl_salfamilia.Location = new System.Drawing.Point(44, 366);
            this.lbl_salfamilia.Name = "lbl_salfamilia";
            this.lbl_salfamilia.Size = new System.Drawing.Size(79, 13);
            this.lbl_salfamilia.TabIndex = 5;
            this.lbl_salfamilia.Text = "Salário Família:";
            // 
            // lbl_saliquido
            // 
            this.lbl_saliquido.AutoSize = true;
            this.lbl_saliquido.Location = new System.Drawing.Point(44, 412);
            this.lbl_saliquido.Name = "lbl_saliquido";
            this.lbl_saliquido.Size = new System.Drawing.Size(79, 13);
            this.lbl_saliquido.TabIndex = 6;
            this.lbl_saliquido.Text = "Salário Liquido:";
            // 
            // lbl_descINSS
            // 
            this.lbl_descINSS.AutoSize = true;
            this.lbl_descINSS.Location = new System.Drawing.Point(366, 286);
            this.lbl_descINSS.Name = "lbl_descINSS";
            this.lbl_descINSS.Size = new System.Drawing.Size(84, 13);
            this.lbl_descINSS.TabIndex = 7;
            this.lbl_descINSS.Text = "Desconto INSS:";
            // 
            // lbl_descIRPF
            // 
            this.lbl_descIRPF.AutoSize = true;
            this.lbl_descIRPF.Location = new System.Drawing.Point(366, 328);
            this.lbl_descIRPF.Name = "lbl_descIRPF";
            this.lbl_descIRPF.Size = new System.Drawing.Size(83, 13);
            this.lbl_descIRPF.TabIndex = 8;
            this.lbl_descIRPF.Text = "Desconto IRPF:";
            // 
            // mskbx_salbruto
            // 
            this.mskbx_salbruto.Location = new System.Drawing.Point(169, 70);
            this.mskbx_salbruto.Mask = "99000.00";
            this.mskbx_salbruto.Name = "mskbx_salbruto";
            this.mskbx_salbruto.Size = new System.Drawing.Size(157, 20);
            this.mskbx_salbruto.TabIndex = 9;
            this.mskbx_salbruto.Validated += new System.EventHandler(this.mskbx_salbruto_Validated);
            // 
            // txt_funcionario
            // 
            this.txt_funcionario.Location = new System.Drawing.Point(169, 37);
            this.txt_funcionario.Name = "txt_funcionario";
            this.txt_funcionario.Size = new System.Drawing.Size(157, 20);
            this.txt_funcionario.TabIndex = 10;
            this.txt_funcionario.Validated += new System.EventHandler(this.txt_funcionario_Validated);
            // 
            // cbx_filhos
            // 
            this.cbx_filhos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_filhos.FormattingEnabled = true;
            this.cbx_filhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbx_filhos.Location = new System.Drawing.Point(169, 101);
            this.cbx_filhos.Name = "cbx_filhos";
            this.cbx_filhos.Size = new System.Drawing.Size(157, 21);
            this.cbx_filhos.TabIndex = 11;
            // 
            // txt_aliINSS
            // 
            this.txt_aliINSS.Enabled = false;
            this.txt_aliINSS.Location = new System.Drawing.Point(148, 283);
            this.txt_aliINSS.Name = "txt_aliINSS";
            this.txt_aliINSS.Size = new System.Drawing.Size(156, 20);
            this.txt_aliINSS.TabIndex = 12;
            // 
            // txt_salfamilia
            // 
            this.txt_salfamilia.Enabled = false;
            this.txt_salfamilia.Location = new System.Drawing.Point(148, 363);
            this.txt_salfamilia.Name = "txt_salfamilia";
            this.txt_salfamilia.Size = new System.Drawing.Size(156, 20);
            this.txt_salfamilia.TabIndex = 13;
            // 
            // txt_aliIRPF
            // 
            this.txt_aliIRPF.Enabled = false;
            this.txt_aliIRPF.Location = new System.Drawing.Point(148, 325);
            this.txt_aliIRPF.Name = "txt_aliIRPF";
            this.txt_aliIRPF.Size = new System.Drawing.Size(156, 20);
            this.txt_aliIRPF.TabIndex = 14;
            // 
            // txt_descIRPF
            // 
            this.txt_descIRPF.Enabled = false;
            this.txt_descIRPF.Location = new System.Drawing.Point(481, 325);
            this.txt_descIRPF.Name = "txt_descIRPF";
            this.txt_descIRPF.Size = new System.Drawing.Size(174, 20);
            this.txt_descIRPF.TabIndex = 15;
            // 
            // txt_descINSS
            // 
            this.txt_descINSS.Enabled = false;
            this.txt_descINSS.Location = new System.Drawing.Point(481, 283);
            this.txt_descINSS.Name = "txt_descINSS";
            this.txt_descINSS.Size = new System.Drawing.Size(174, 20);
            this.txt_descINSS.TabIndex = 16;
            // 
            // txt_salliquido
            // 
            this.txt_salliquido.Enabled = false;
            this.txt_salliquido.Location = new System.Drawing.Point(148, 409);
            this.txt_salliquido.Name = "txt_salliquido";
            this.txt_salliquido.Size = new System.Drawing.Size(156, 20);
            this.txt_salliquido.TabIndex = 17;
            // 
            // btn_verificar
            // 
            this.btn_verificar.Location = new System.Drawing.Point(169, 151);
            this.btn_verificar.Name = "btn_verificar";
            this.btn_verificar.Size = new System.Drawing.Size(157, 23);
            this.btn_verificar.TabIndex = 18;
            this.btn_verificar.Text = "Verficar desconto";
            this.btn_verificar.UseVisualStyleBackColor = true;
            this.btn_verificar.Click += new System.EventHandler(this.btn_verificar_Click);
            // 
            // rbtn_masculino
            // 
            this.rbtn_masculino.AutoSize = true;
            this.rbtn_masculino.Checked = true;
            this.rbtn_masculino.Location = new System.Drawing.Point(26, 32);
            this.rbtn_masculino.Name = "rbtn_masculino";
            this.rbtn_masculino.Size = new System.Drawing.Size(73, 17);
            this.rbtn_masculino.TabIndex = 19;
            this.rbtn_masculino.TabStop = true;
            this.rbtn_masculino.Text = "Masculino";
            this.rbtn_masculino.UseVisualStyleBackColor = true;
            // 
            // rbtn_feminino
            // 
            this.rbtn_feminino.AutoSize = true;
            this.rbtn_feminino.Location = new System.Drawing.Point(26, 63);
            this.rbtn_feminino.Name = "rbtn_feminino";
            this.rbtn_feminino.Size = new System.Drawing.Size(67, 17);
            this.rbtn_feminino.TabIndex = 20;
            this.rbtn_feminino.Text = "Feminino";
            this.rbtn_feminino.UseVisualStyleBackColor = true;
            // 
            // grpbx_sexo
            // 
            this.grpbx_sexo.Controls.Add(this.rbtn_masculino);
            this.grpbx_sexo.Controls.Add(this.rbtn_feminino);
            this.grpbx_sexo.Location = new System.Drawing.Point(455, 37);
            this.grpbx_sexo.Name = "grpbx_sexo";
            this.grpbx_sexo.Size = new System.Drawing.Size(200, 100);
            this.grpbx_sexo.TabIndex = 21;
            this.grpbx_sexo.TabStop = false;
            this.grpbx_sexo.Text = "Sexo:";
            // 
            // pnl_casado
            // 
            this.pnl_casado.Controls.Add(this.chkbx_casado);
            this.pnl_casado.Location = new System.Drawing.Point(455, 151);
            this.pnl_casado.Name = "pnl_casado";
            this.pnl_casado.Size = new System.Drawing.Size(186, 82);
            this.pnl_casado.TabIndex = 22;
            // 
            // chkbx_casado
            // 
            this.chkbx_casado.AutoSize = true;
            this.chkbx_casado.Location = new System.Drawing.Point(26, 34);
            this.chkbx_casado.Name = "chkbx_casado";
            this.chkbx_casado.Size = new System.Drawing.Size(62, 17);
            this.chkbx_casado.TabIndex = 23;
            this.chkbx_casado.Text = "Casado";
            this.chkbx_casado.UseVisualStyleBackColor = true;
            // 
            // lbl_dados
            // 
            this.lbl_dados.AutoSize = true;
            this.lbl_dados.Location = new System.Drawing.Point(44, 220);
            this.lbl_dados.Name = "lbl_dados";
            this.lbl_dados.Size = new System.Drawing.Size(125, 13);
            this.lbl_dados.TabIndex = 23;
            this.lbl_dados.Text = "Aguardando informações";
            // 
            // PSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 479);
            this.Controls.Add(this.lbl_dados);
            this.Controls.Add(this.pnl_casado);
            this.Controls.Add(this.grpbx_sexo);
            this.Controls.Add(this.btn_verificar);
            this.Controls.Add(this.txt_salliquido);
            this.Controls.Add(this.txt_descINSS);
            this.Controls.Add(this.txt_descIRPF);
            this.Controls.Add(this.txt_aliIRPF);
            this.Controls.Add(this.txt_salfamilia);
            this.Controls.Add(this.txt_aliINSS);
            this.Controls.Add(this.cbx_filhos);
            this.Controls.Add(this.txt_funcionario);
            this.Controls.Add(this.mskbx_salbruto);
            this.Controls.Add(this.lbl_descIRPF);
            this.Controls.Add(this.lbl_descINSS);
            this.Controls.Add(this.lbl_saliquido);
            this.Controls.Add(this.lbl_salfamilia);
            this.Controls.Add(this.lbl_aliIRPF);
            this.Controls.Add(this.lbl_aliINSS);
            this.Controls.Add(this.lbl_filhos);
            this.Controls.Add(this.lbl_salbruto);
            this.Controls.Add(this.lbl_funcionario);
            this.Name = "PSalario";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbx_sexo.ResumeLayout(false);
            this.grpbx_sexo.PerformLayout();
            this.pnl_casado.ResumeLayout(false);
            this.pnl_casado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_funcionario;
        private System.Windows.Forms.Label lbl_salbruto;
        private System.Windows.Forms.Label lbl_filhos;
        private System.Windows.Forms.Label lbl_aliINSS;
        private System.Windows.Forms.Label lbl_aliIRPF;
        private System.Windows.Forms.Label lbl_salfamilia;
        private System.Windows.Forms.Label lbl_saliquido;
        private System.Windows.Forms.Label lbl_descINSS;
        private System.Windows.Forms.Label lbl_descIRPF;
        private System.Windows.Forms.MaskedTextBox mskbx_salbruto;
        private System.Windows.Forms.TextBox txt_funcionario;
        private System.Windows.Forms.ComboBox cbx_filhos;
        private System.Windows.Forms.TextBox txt_aliINSS;
        private System.Windows.Forms.TextBox txt_salfamilia;
        private System.Windows.Forms.TextBox txt_aliIRPF;
        private System.Windows.Forms.TextBox txt_descIRPF;
        private System.Windows.Forms.TextBox txt_descINSS;
        private System.Windows.Forms.TextBox txt_salliquido;
        private System.Windows.Forms.Button btn_verificar;
        private System.Windows.Forms.RadioButton rbtn_masculino;
        private System.Windows.Forms.RadioButton rbtn_feminino;
        private System.Windows.Forms.GroupBox grpbx_sexo;
        private System.Windows.Forms.Panel pnl_casado;
        private System.Windows.Forms.CheckBox chkbx_casado;
        private System.Windows.Forms.Label lbl_dados;
    }
}

